"""Bundled data assets (fixtures)."""
