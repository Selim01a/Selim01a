@echo off
cd /d "%~dp0"
REM Critical: offscreen Qt breaks the 3D viewer on Windows.
set QT_OPENGL=desktop
if /I "%QT_QPA_PLATFORM%"=="offscreen" set QT_QPA_PLATFORM=
echo Installing ENGINEERING//CORE 3D desktop extras...
python -m pip install -e ".[desktop]"
if errorlevel 1 (
  echo pip failed. Install Python 3.11/3.12 and check PATH.
  pause
  exit /b 1
)
echo Launching 3D workspace...
python -m engcore.desktop
if errorlevel 1 pause
