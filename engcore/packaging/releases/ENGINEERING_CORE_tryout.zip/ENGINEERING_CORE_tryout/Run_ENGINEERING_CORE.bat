@echo off
cd /d "%~dp0"
echo Installing ENGINEERING//CORE desktop extras...
python -m pip install -e ".[desktop]"
if errorlevel 1 (
  echo pip failed. Is Python on PATH?
  pause
  exit /b 1
)
python -m engcore.desktop
if errorlevel 1 pause
